﻿// ---------------------------------------------------------------
// Copyright (c) Coalition of the Good-Hearted Engineers
// FREE TO USE AS LONG AS SOFTWARE FUNDS ARE DONATED TO THE POOR
// ---------------------------------------------------------------

using System.Collections.Generic;

namespace OtripleS.Web.Api.Infrastructure.Provision.Models.Configurations
{
    public class CloudAction
    {
        public List<string> Environments { get; set; }
    }
}
