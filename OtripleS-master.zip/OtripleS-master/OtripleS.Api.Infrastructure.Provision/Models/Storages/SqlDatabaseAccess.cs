﻿// ---------------------------------------------------------------
// Copyright (c) Coalition of the Good-Hearted Engineers
// FREE TO USE AS LONG AS SOFTWARE FUNDS ARE DONATED TO THE POOR
// ---------------------------------------------------------------

namespace OtripleS.Web.Api.Infrastructure.Provision.Models.Storages
{
    public class SqlDatabaseAccess
    {
        public string AdminName { get; set; }
        public string AdminAccess { get; set; }
    }
}
